import random as rnd


def extract_my_data():
    data_file = "airfoil_self_noise_.csv"
    in_file = open(data_file, 'r')
    my_file = open("airfoil_ikb_.csv", 'w')

    rnd.seed(17)
    for line in in_file:
        r = rnd.random()
        if r < 0.1:
            my_file.writelines(line)

    in_file.close()
    my_file.close()


def split_train_and_test():
    pass


if __name__ == "__main__":
    extract_my_data()
    split_train_and_test()

